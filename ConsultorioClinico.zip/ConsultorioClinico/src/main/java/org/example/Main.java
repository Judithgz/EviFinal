package org.example;

import org.example.CONTROLADOR.Controlador;

public class Main {
    public static void main(String[] args) {
        Controlador c = new Controlador();
        c.iniciar();
    }
}